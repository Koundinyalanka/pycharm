from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def hello_world():
   return render_template('welcome.html');

@app.route('/api/v1/view_batch')
def view_batch_output():
   return render_template('batch_view.html');

@app.route('/api/v1/view_batch',methods=['POST'])
def get_post_batch():
    if(request.method=='POST'):
        batch_id=request.form.get('batch',None);
        print(batch_id)
        data = [
            {
                'name': batch_id,
            }
        ]
    return render_template('batch_view.html',data=data);


if __name__ == '__main__':
   app.debug=True;

   #jdbc:teradata://UDWDEV/DATABASE=UDWETLSANDBOX,DBS_PORT=1025,LOGMECH=LDAP,TMODE=TERA
   app.run(host='0.0.0.0',port=80)